package com.yindangu.demo;

import com.yindangu.demo.util.Number2UppercaseUtil;

/**具体的业务类(完全与V平台无关了)*/
class BusinessFunc{
	/**业务实现*/
	public String execute(int rowIdx ){
		String ns =Number2UppercaseUtil.toUpperCase(rowIdx) + "v1";
		return  ns; 
	}
}

