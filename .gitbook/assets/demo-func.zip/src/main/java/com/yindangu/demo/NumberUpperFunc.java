package com.yindangu.demo;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.toone.itop.paas.extension.api.IFunction;
/**
 * 数字转换成汉字
代码示例:NumberUpperFunc(3,"name",实体)，返回值: 九万二千二百八十七。
入口: com.yindangu.demo.NumberUpperFunc
参数1--需转换数字(数值类型)； 
返回汉字大写。 
 * @author jiqj
 *
 */
public class NumberUpperFunc  implements IFunction {
	private static final Logger log = LoggerFactory.getLogger(NumberUpperFunc.class);
	public NumberUpperFunc(){
		log.info("函数:数字转换成汉字");
	}

	public Object evaluate(IFuncContext context) {
		/////////////////参数检查///////////////////
		Number nb = (Number)context.getParams(0);//参数1--需转换数字(数值类型)
		//String column = (String)context.getParams(1);//参数2--可以接收多参数的例子
		//Date today = (Date)context.getParams(2);//参数3--可以接收多参数的例子
		if(nb == null){
			throw new RuntimeException("参数1--行数不能为空！");
		}
		////////////////业务实现 api 完全与V平台无关////////////////////
		BusinessFunc fb = new BusinessFunc();
		String rs = fb.execute(nb.intValue());
		return rs;
	}
	

	/**
	 * 单机调试代码
	 * @param args
	 */
	public static void main(String[] args){
		final List<Object> pars = new ArrayList<Object>();
		pars.add(92287);
		IFuncContext fc = new IFuncContext() { 
			public int getParamSize() { 
				return pars.size();
			}
			public Object getParams(int idx) { 
				return (idx < pars.size() ? pars.get(idx) : null);
			}
		};
		
		IFunction  func = new NumberUpperFunc(); 
		Object fr = func.evaluate(fc);
		log.info("函数返回:"  + fr);
	}
}