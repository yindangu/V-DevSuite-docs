 /*
 * 需求：打折促销，将商品价格按照打折方案转换成最后销售价格
 * 客户端规则的默认入口方法名为evaluate; params为规则入参,参数格式为json对象
 * 入参格式：
 * {
 * 		discount:1,//折扣
 * 		goods:[{//商品列表
 * 			id:"",//商品id
 * 			price:""//商品价格
 * 		}
 * 		...
 * 		]
 * }
 * 输出参数：
 * {
 * 		goods:[{//商品列表
 * 			id:"",//商品id
 * 			price:""//商品价格
 * 		}
 * 		...
 * 		]
 * }
 */
let evaluate = function (params) {
    return new Promise((resolve,reject)=>{
		let discount = parseFloat(params.discount);
		if(isNaN(discount)){
			reject(Error("折扣信息有误！discount="+discount));
		}else if(discount<0){
			reject(Error("折扣需大于零！discount="+discount));
		}else{
			let goods = params.goods||[];
			let result = [];
			goods.forEach(item => {
				let good = {
					id:item.id
				};
				let price = parseFloat(item.price);
				if(!isNaN(price)){
					good.price = price * discount;
				}
				result.push(good);
			});
			resolve({
				goods : result
			});
		}
    });
};

export {
    evaluate
}