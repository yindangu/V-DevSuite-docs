/*
 * 需求：将数值转换成中文
 * 客户端规则的默认入口方法名为evaluate; params为规则入参,参数格式为json对象
 */
let cnNum = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
let numToCN = function(num){
	 let numStr = num+"";
	 let result = [];
	 for(let i=0,len=numStr.length;i<len;i++){
		 let index = parseInt(numStr.charAt(i));
		result.push(cnNum[index]);
	 }
	 return result.join('');
 }
let evaluate = function (params) {
    return new Promise((resolve,reject)=>{
		let input = params.input;
		let num = parseInt(input);
		if(isNaN(num)){
			reject(Error("请输入整数！"));
		}else if(num<0){
			reject(Error("请输入大于零的整数！"));
		}else{
			resolve({
				out : numToCN(num)
			});
		}
    });
};

export {
    evaluate
}