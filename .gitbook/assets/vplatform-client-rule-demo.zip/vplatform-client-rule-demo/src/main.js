//客户端规则的默认入口方法名为evaluate; ruleContext为规则入参,参数格式为json对象
var evaluate = function (ruleContext) {
    console.log("hello vplatform!");
    alert(ruleContext.prop1 + " " + ruleContext.prop2 + "!");
};

export {
    evaluate
}