package com.yindangu.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.yindangu.demo.util.Number2UppercaseUtil;

/**具体的业务类(完全与V平台无关了)*/
class BusinessRule{   
	/**
	 * 业务实现 : 把指定列转换为汉字大写
	 * @param column
	 * @param sourceEntity
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Map> convertEntity(String column,List<Map> sourceEntity){
		List<Map> rds = new ArrayList<Map>();
		if(sourceEntity == null || sourceEntity.isEmpty()){
			Map<String,Object> map = new HashMap<String, Object>();
			map.put(column, "没有记录");
			rds.add(map);
		}
		else{
			for(Map src: sourceEntity){
				Map<String,Object> map = new HashMap<String, Object>(src);
				Integer age = (Integer)map.get(column); 
				String myage = "无";
				if(age!=null){
					myage = Number2UppercaseUtil.toUpperCase(age.longValue());
				}
				map.put(column, myage ); 
				rds.add(map);
			}
		}
		return rds;
	} 
}