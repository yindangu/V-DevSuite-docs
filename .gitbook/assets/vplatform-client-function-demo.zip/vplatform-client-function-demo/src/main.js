//客户端函数的默认入口方法名为evaluate; param1和param2为自定义的函数入参声明
var evaluate = function (param1, param2) {
    console.log("hello vplatform!");
    return param1 + " " + param2 + "!";
};

export {
    evaluate
}