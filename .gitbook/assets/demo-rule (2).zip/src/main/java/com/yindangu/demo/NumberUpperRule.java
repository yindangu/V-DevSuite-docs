package com.yindangu.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.toone.itop.paas.extension.api.IRule;
/**
规则功能：
把实体某列转换为汉字大写
输入参数2个：列名-字符串需转换的列名，实体
输出参数1个：转换后的实体
入口: com.yindangu.demo.NumberUpperRule
代码示例:NumberUpperFunc("age",实体)

参数:[{code:column,type:string},
	{code:myentity,type:entity,"entityField": [
       {
            "code": [参数列],
            "type": "int" 
        },...
    ]}

返回 {
  myentity:{
     type:entity,"entityField": [
        {
            "code": [参数列],
            "type": "char" 
        }, ...
    ]}
  }
 * @author jiqj 
 */
public class NumberUpperRule implements IRule {
 
	private static final Logger log = LoggerFactory.getLogger(NumberUpperRule.class);
	public NumberUpperRule(){
		log.info("规则:指定数据实体某行某列的值转换为汉字大写");
	}

	/**
	 * 规则入口
	 * @return 返回值必须是Map(定义为Object是为了以后扩展),所有返回值都要put到map里面
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Object evaluate(IRuleContext context) {
		/////////////////参数检查///////////////////
		String column = (String)context.getParams("column");//需转换的列名
		//Date today = (Date)context.getParams("today");//日期参数--可以接收多参数的例子
		List<Map> entity = (List<Map>)context.getParams("myentity");//实体
		if(column == null){
			throw new RuntimeException("参数column--列名不能为空！");
		}
		if(entity == null){
			throw new RuntimeException("转换参数myentity--实体不能为空！");
		}		
		////////////////业务实现 api 完全与V平台无关////////////////////
		BusinessRule br = new BusinessRule();
		List<Map> entity2 = br.convertEntity(column, entity);
		
		//输出的key: myentity 具体可以构件定义
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("myentity", entity2);
		return map;
	}
	
	/**自测代码*/
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args){ 
		List<Map> entity = mockEntity();
		final HashMap<String,Object> pars = new HashMap<String,Object>();
		pars.put("column", "age");//需转换的列名
		pars.put("myentity", entity);//实体
		
		IRuleContext context = new IRuleContext() {
			public int getParamSize() { 
				return pars.size();
			}
			public Object getParams(String key) { 
				return pars.get(key);
			}
		}; 
		
		
		IRule  rule = new NumberUpperRule();
		Map<String,Object>  result =(Map<String,Object>) rule.evaluate(context);
		List<Map> entity2 =(List<Map>) result.get("myentity");
		for(Map m : entity2){
			log.info(m.get("myname") + ") 年龄: "  + m.get("age"));
		}
	}
	/**自测代码*/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static List<Map> mockEntity(){
		List<Map> entity =new ArrayList();
		Map<String,Object> m =  new HashMap();
		m.put("myname","李四");
		m.put("age",40);
		entity.add(m);
		
		Map<String,Object> s =  new HashMap();
		s.put("myname","张三");
		s.put("age",39);
		entity.add(s);
		return entity;
	}
}