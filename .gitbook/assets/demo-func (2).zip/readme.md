如果在eclipse里死活更新不了 paas-extension.jar
那么就需要使用mvn命令行更新了（我们验证过有时eclipse能更新，有时候有不行，用mvn命令基本都可以更新）
只把demo的settings.xml复制到maven/conf里，然后在demo目录跑 mvn package 就可以了