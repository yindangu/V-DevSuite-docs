
let cnNum = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
 /**
  * 需求：将整数转换成中文
  * 客户端函数的默认入口方法名为evaluate; param1为自定义的函数入参声明
  */
var evaluate = function (param1) {
	let num = parseInt(param1);
	if(isNaN(num)){
		throw Error("请输入整数！");
	}else if(num<0){
		throw Error("请输入大于零的整数！");
	}else{
		let numStr = num+"";
		let result = [];
		for(let i=0,len=numStr.length;i<len;i++){
			let index = parseInt(numStr.charAt(i));
			result.push(cnNum[index]);
		}
		return result.join('');
	}
};

export {
    evaluate
}